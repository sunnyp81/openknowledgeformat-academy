# OKF Starter Bundle

A small, spec-conformant example bundle for the Open Knowledge Format (OKF).
Clone it, replace the placeholder content, and you have a working knowledge
bundle for your own data, metrics, and operations.

## What this is

OKF is an open specification for packaging the metadata, context, and curated
knowledge that AI agents and humans need, as a directory of UTF-8 markdown
files with YAML frontmatter. Each concept document requires only a non-empty
`type` field; everything else is optional.

## Layout

    okf-starter-bundle/
      README.md      this file
      LICENSE        CC0 1.0, public domain
      index.md       reserved: directory listing
      log.md         reserved: update history
      orders.md      type: table
      signup-rate.md type: metric
      restart-api.md type: runbook
      status-api.md  type: api

## How to use

1. Replace the "Acme" and "REPLACE" placeholders with your own content.
2. Keep a non-empty `type` in every concept's frontmatter.
3. Keep index.md and log.md at the root; they are reserved filenames.
4. Record changes in log.md and commit to version control.

## Not affiliated with Google

This template is an independent resource. OKF is an open specification; this
bundle is not produced, endorsed by, or affiliated with Google. See the
official specification for the authoritative rules:
https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md

## License

CC0 1.0 Universal. See LICENSE.
