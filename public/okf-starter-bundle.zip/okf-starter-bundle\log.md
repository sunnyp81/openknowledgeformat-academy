---
type: log
title: Change log
description: Update history for the starter bundle.
timestamp: 2026-06-26T09:00:00Z
---

# Change log

## 2026-06-26
- Initial starter bundle: one table, metric, runbook, and api concept.

<!-- Add a dated entry here every time you change the bundle. Newest first. -->
