---
type: table
title: orders
description: REPLACE. One row per completed customer order.
resource: REPLACE://your-warehouse/dataset/orders
tags: [REPLACE, table, example]
timestamp: 2026-06-26T09:00:00Z
---

# orders

REPLACE this with a one-line statement of the table grain, for example:
"One row per completed order. Refunds live in a separate table."

## Columns

| Column      | Type      | Description                          |
|-------------|-----------|--------------------------------------|
| order_id    | STRING    | REPLACE. Primary key.                |
| customer_id | STRING    | REPLACE. Foreign key to customers.   |
| order_ts    | TIMESTAMP | REPLACE. Order confirmation time, UTC.|
| status      | STRING    | REPLACE. placed, shipped, cancelled. |
| amount      | NUMERIC   | REPLACE. Order total, your currency. |

## Notes

- REPLACE with anything an agent should know before using this table,
  such as how cancellations or refunds are handled.
