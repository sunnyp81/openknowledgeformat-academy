---
type: metric
title: Signup Rate
description: REPLACE. Share of visitors who create an account.
resource: https://wiki.example.com/metrics/signup-rate
tags: [REPLACE, metric, conversion]
timestamp: 2026-06-26T09:00:00Z
---

# Signup Rate

REPLACE with the agreed definition. Example:

    signup_rate = new_signups / unique_visitors

Window: REPLACE, for example a rolling 7-day window.

## Inclusions and exclusions

- REPLACE. State what counts as a signup and a visitor.
- REPLACE. Note any bot filtering or deduplication.

## Targets

- REPLACE with your healthy, watch, and action thresholds.
