---
type: api
title: Status API
description: REPLACE. Public health-check endpoint.
resource: https://api.example.com/v1/status
tags: [REPLACE, api, health]
timestamp: 2026-06-26T09:00:00Z
---

# Status API

`GET /v1/status`

REPLACE with a one-line description. Returns service health. No auth required.

## Response

REPLACE. Example:

    { "status": "ok", "version": "1.4.2", "time": "2026-06-26T09:00:00Z" }

## Notes

- REPLACE. Rate limits, caching, or anything a caller should know.
