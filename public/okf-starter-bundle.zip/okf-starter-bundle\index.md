---
type: index
title: Acme Starter Knowledge
description: A starter OKF bundle. Replace these concepts with your own.
tags: [starter, example]
timestamp: 2026-06-26T09:00:00Z
---

# Acme Starter Knowledge

REPLACE this with a one-paragraph summary of what your bundle covers.

This starter contains one concept of each common type so you can see the
shape, then swap in your real assets.

## Concepts

- [orders](orders.md) - table. One row per completed order.
- [signup-rate](signup-rate.md) - metric. Visitor to signup conversion.
- [restart-api](restart-api.md) - runbook. Recovering the API service.
- [status-api](status-api.md) - api. Public health-check endpoint.

## How to read this bundle

Start here, then open only the concepts you need. Each file is independent and
human-readable without any tooling.
