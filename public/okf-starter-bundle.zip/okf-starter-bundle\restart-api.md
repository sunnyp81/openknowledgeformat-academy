---
type: runbook
title: Restart the API service
description: REPLACE. Steps to safely restart the public API.
resource: https://ops.example.com/runbooks/restart-api
tags: [REPLACE, runbook, oncall]
timestamp: 2026-06-26T09:00:00Z
---

# Runbook: restart the API service

Trigger: REPLACE, for example "health check returns 5xx for over 2 minutes".

## 1. Confirm

- REPLACE. How to verify the service is actually unhealthy.

## 2. Act

- REPLACE. The exact restart command or console steps.

## 3. Verify recovery

- REPLACE. How to confirm the service is healthy again.

## Escalation

- REPLACE. Who to contact if the restart does not resolve it.
